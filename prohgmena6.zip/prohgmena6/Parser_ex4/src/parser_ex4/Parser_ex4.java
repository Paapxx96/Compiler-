/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser_ex4;

import java.util.ArrayList;

public class Parser_ex4 {

    static ArrayList<Token> tokens;
    static Token token;

    private static Token next() {
        token = tokens.remove(0);
        System.out.format("%s %s %d\n",token.data,token.type,token.line);
        return token;
    }

    public static void error(String s) {
        System.out.format("error in line %d: %s\n", token.line, s);
        System.exit(0);
    }

    //-------------------------------------------------------------------
    // program = PROGRAM ID declarations BODY statement EOF
    //------------------------------------------------------------------- 
    public static void program() {
    // opou vriskei comments kai whitespace kane skip
    while (token.type.name().equals("whitespaceTK") || token.type.name().equals("commentTK")) {
        token = next();  //me auton ton tropo skiparei ta comments kai whitespaces
    }
    // me to pou ksekinhsei h main kaleite to program opote perimenei to PROGRAM keyword
    if (!token.type.name().equals("programTK")) {
        error("Expected 'PROGRAM' at the beginning");//mnm la9ous an den to vrei
    }
    token = next();  //an ftasei edw shmainei oti vrike PROGRAM kai to proxwraei gia na elegksei to epomeno token

    //meta to PROGRAM perimenei to onoma tou programmatos AKA identifier
    if (token.type != TokenType.identifierTK) {
        error("Expected an identifier after 'PROGRAM'");
    }
    token = next();  // vrike identifier opote proxwraei sto epomeno token

    // checkarei aan uparxoun declarations ( VAR )
    declarations();

    // meta to declaration (eite egine eite oxi) perimenei na vrei BODY keyword
    if (!token.type.name().equals("bodyTK")) {
        error("Expected 'BODY' after declarations");
    }
    token = next();  

    // kai meta ksekinane ta statements
    statement();

    // sto telos perimenei to EOF 
    if (token.type != TokenType.eofTK) {
        error("Expected end of file (EOF)");
    }
}   

    //-------------------------------------------------------------------
    // declarations = VAR decl (SEMICOLON decl)* | ε
    //------------------------------------------------------------------- 
    public static void declarations() {
    if (token.type.name().equals("varTK")) {
        token = next();  // paei sto epomeno token apo to VAR
        decl();  // Process the first declaration

        while (token.type.name().equals("semicolonTK")) {
            token = next();  // Move past semicolon
            decl();  // Process next declaration
        }
    }//to VAR einai proeretiko gia auto den yparxei else
    }

    //-------------------------------------------------------------------
    // decl = idList COLON type
    //------------------------------------------------------------------- 
    public static void decl() {
        idList();//kalei thn idList gia na perasei ola ta declarations
        if (token.type.name().equals("colonTK")) {//meta ta declarations perimenei :
            token = next();
            type();//afou perase ta identifiers kai vrike : perimenei ton typo twn metavlhtwn
        } else {
            error("COLON seperator expected in variable type declaration");
        }
    }

    //-------------------------------------------------------------------
    // idList =	ID (COMMA ID)*
    //------------------------------------------------------------------- 
    public static void idList() {//
    if (token.type.name().equals("identifierTK")) {
        token = next();  // arxika vriskei identifier
        // kai meta mporei na exei koma prepei na exei kai allo identifier,se mia while giati mporei na valei osa 9eleei
        while (token.type.name().equals("commaTK")) {
            token = next();  
            if (!token.type.name().equals("identifierTK")) {
                error("Expected identifier after comma");
            }
            token = next();  
        }
    } else {
        error("Expected identifier");
    }
    }

    //-------------------------------------------------------------------
    // type = basicType | arrayType
    //------------------------------------------------------------------- 
    public static void type() {
    if (token.type.name().equals("arrayTK")) {
        arrayType();  //elegxei an einai array Type 
    } else {
        basicType();  //h basic type
    }
    }

    //-------------------------------------------------------------------
    // basicType = INTEGER | BOOLEAN |STRING
    //------------------------------------------------------------------- 
    public static void basicType() {
        switch (token.type.name()) {
            case "integerTK": {//an einai kapoio apo ta parakatw einai komple
                token = next();//kai to kanei skip
                break;
            }
            case "booleanTK": {
                token = next();
                break;
            }
            case "stringTK": {
                token = next();
                break;
            }
            default: {
                error("Unknown data type");
                break;
            }
        }
    }

    //-------------------------------------------------------------------
    // arrayType = ARRAY LBRACK NUMERIC RBRACK OF basicType
    //------------------------------------------------------------------- 
    public static void arrayType() {
        if (token.type.name().equals("arrayTK")) {
            token = next();
            if (token.type.name().equals("lbrackTK")) {
                token = next();
                if (token.type.name().equals("numericTK")) {
                    token = next();
                    if (token.type.name().equals("rbrackTK")) {
                        token = next();
                        if (token.type.name().equals("ofTK")) {
                            token = next();
                            basicType();
                        } else {
                            error("OF keyword expected in array variable declaration");
                        }
                    } else {
                        error("RBRACK expected in array variable declaration");
                    }
                } else {
                    error("Numeric constant expected in array variable declaration");
                }
            } else {
                error("LBRACK expected in array variable declaration");
            }
        } else {
            error("ARRAY keyword expected in array variable declaration");
        }
    }
    
    //-------------------------------------------------------------------
    // statement = BEGIN block END
    //          | lvalue ASSIGN expr
    //          | READ LPAREN idList RPAREN
    //          | WRITE LPAREN exprList RPAREN
    //          | IF expr THEN statement (ELSE statement)?
    //          | WHILE expr DO statement
    //          | EXIT
    //------------------------------------------------------------------- 
    public static void statement() {    
    switch (token.type.name()) {//elegxei to token
        case "beginTK":
            token = next();  //an einai BEGIN to proxwraei
            block();  //kai perimenei ena block
            //to block proxwrhse osa statement eixe kai meta perimenei to END
            if (!token.type.name().equals("endTK")) {
                error("Expected 'END' after block");
            }
            token = next();
            break;//proxwrame apo to END kai vgainoume apo to case

        case "identifierTK": 
            lvalue();//edw pernei to identifier eite metavlhth eite pinakas
            if (!token.type.name().equals("assignTK")) {//kai edw perimenei to := gia na dwsei timh
                error("Expected ':=' for assignment");
            }
            token = next(); 
            expr(); 
            break;

        case "readTK":// afou vrei to READ perimenei se mia parenthesi oles tis metavlhtes gia diavasma xwrismenes me komma
            token = next();
            if (!token.type.name().equals("lparenTK")) {
                error("Expected '(' after 'READ'");
            }//sthn arxh perimenei aristerh parenthesh
            token = next();  
            idList();  //meta vriskei osa identifiers xwrismena me koma yparxoun
            if (!token.type.name().equals("rparenTK")) {
                error("Expected ')' after identifiers");
            }//kai meta kleinei me deksia parenthesh
            token = next();
            break;

        case "writeTK"://sto grapsimo perimenei se mia parenthesi ti 9a tupwsei
            token = next();  
            if (!token.type.name().equals("lparenTK")) {
                error("Expected '(' after 'WRITE'");
            }
            token=next();
            exprList();  // 
             
            if (!token.type.name().equals("rparenTK")) {
                error("Expected ')' after expression list");
            }
            token = next();  // Move past ")"
            break;

        case "ifTK":
            token = next();  // Move to expression
            expr();  // Parse the expression
            if (!token.type.name().equals("thenTK")) {
                error("Expected 'THEN' after 'IF'");
            }
            token = next();  // Move to the statement
            statement();  // Handle the THEN block
            if (token.type.name().equals("elseTK")) {
                token = next();  // Move to ELSE block
                statement();  // Handle the ELSE block
            }
            break;

        case "whileTK":
            token = next();  // epanalhpsh while
            expr();  //vlepei ti exei ws sun9hkh h while

            if (!token.type.name().equals("doTK")) {//meta thn sun9hkh perimenei to DO
                error("Expected 'DO' after 'WHILE'");
            }
            token = next();  // proxwraei meta to DO
            statement();  // kai edw elegxei to eswteriko ths epanalhpshs
            break;

        case "exitTK":
            token = next();
            break;

        default:
            error("Unexpected statement");
            break;
    }
    }
    
    //-------------------------------------------------------------------
    // block = statement (SEMICOLON statement)* | ε
    //------------------------------------------------------------------- 
    public static void block() {
        while (token.type.name().equals("commentTK") || token.type.name().equals("whitespaceTK")) {
        token = next();  //proxwrame comments kai kena
        }
            
         if (token.type.name().equals("endTK")) {//an yparxei keno block tote den xreiazetai epeksergasia
             return;
         }
            
        if (!token.type.name().equals("semicolonTK")) {
            statement();  // vlepoume to prwto statement sto block
            while (token.type.name().equals("semicolonTK")) {
                token = next();  //ama exei komma proxwrame kai vlepoume kai to epomeno statement
                while (token.type.name().equals("commentTK") || token.type.name().equals("whitespaceTK")) {
                    token = next();  //pali skiparoume ta comments kai kena gia na mhn ta kanei parse
                }
                statement();//ousiastika vlepoume statements kai an exei komma perimenoume kai allo statement alliws la9os
            }
        }
    }
    
    
    
    //-------------------------------------------------------------------
    // lvalue =	ID args
    //------------------------------------------------------------------- 
    public static void lvalue() {
        if (token.type.name().equals("identifierTK")) {
            token = next();
            args();//elegxei an einai pinakas
        } else {
            error("variable name expected");
        }
    }
    
    //-------------------------------------------------------------------
    // args = LBRACK index RBRACK | ε
    //------------------------------------------------------------------- 
    public static void args() {// an vrei left bracket perimenei ari9mo h metavlhth kai meta right bracket
        if (token.type.name().equals("lbrackTK")) {
            token = next();
            index();
            if (token.type.name().equals("rbrackTK")) {
                token = next();
            } else {
                error("RBRACK expected in array variable reference");
            }
        }
    }
    
    //-------------------------------------------------------------------
    // index = ID | NUMERIC
    //------------------------------------------------------------------- 
    public static void index() {//einai mesa sta bracket opote perimenei ari9mo h metavlhth
    if (token.type.name().equals("numericTK") || token.type.name().equals("identifierTK")) {
        token = next();  //afou to vrhke proxwraei
    } else {
        error("Expected numeric constant or identifier for index");
    }
    }
    
    //-------------------------------------------------------------------
    // exprList	= expr (COMMA expr)*
    //------------------------------------------------------------------- 
    public static void exprList() {//lista apo expression xwrismena apo komma
    expr();//elegxei to expression

    while (token.type.name().equals("commaTK")) {
        token = next();  // an exei komma perimenei kai allo expression
        expr();  
    }
    }
    
    //-------------------------------------------------------------------
    // expr = ..
    //------------------------------------------------------------------- 
    public static void expr() {//deixei ta expression
    additiveExpr();

    
    while (//pou exoun elegxo isothtas an xreiastei alliws mono tou ena expression
            //den mpainei panta sthn while
            token.type.name().equals("plusTK") || 
            token.type.name().equals("minusTK") ||
            token.type.name().equals("notEqualTK") ||
            token.type.name().equals("equalTK") ||
            token.type.name().equals("lteTK") ||
            token.type.name().equals("gteTK") ||
            token.type.name().equals("ltTK") ||
            token.type.name().equals("gtTK") 
            ) {
        relationOperator();
        additiveExpr(); 
         
    }
    }
    
    //-------------------------------------------------------------------
    // logicAND	= ...
    //------------------------------------------------------------------- 
    public static void logicAND() {
    factor();  

    while (token.type.name().equals("andTK")) {
        token = next();  
        factor(); 
    }
    }
    
    //-------------------------------------------------------------------
    // relationExpr = ...
    //------------------------------------------------------------------- 
    public static void relationExpr() {
    expr();  //expression block me expression isothta kai meta kai allo expression
    //ektos an den exei isothta tote exei apla ena expression
    if (
        token.type.name().equals("equalTK") ||
        token.type.name().equals("notEqualTK") ||
        token.type.name().equals("ltTK") ||
        token.type.name().equals("gtTK") ||
        token.type.name().equals("lteTK") ||
        token.type.name().equals("gteTK")
    ) {
        relationOperator(); 
        expr();  
    }
    }
    
    //-------------------------------------------------------------------
    // additiveExpr = ...
    //------------------------------------------------------------------- 
    public static void additiveExpr() {//psaxnei meta ton oro an yparxei kapoia praksh
    term();  

    
    while (token.type.name().equals("plusTK") || 
            token.type.name().equals("minusTK") ||
            token.type.name().equals("concatTK") || 
            token.type.name().equals("timesTK") ||
            token.type.name().equals("divisionTK") ||
            token.type.name().equals("moduloTK")  
            ) {
        addingOperator();  
        term();  
    }
    }
    
    //-------------------------------------------------------------------
    // factor =	...
    //------------------------------------------------------------------- 
    public static void factor() {//elegxei ti tupos einai kai kanei ka9e fora tn analogh douleia mesa sta ifs
    if (token.type.name().equals("numericTK") || token.type.name().equals("stringConstTK")) {
        constant(); 
    } else if (token.type.name().equals("trueTK") || token.type.name().equals("falseTK")) {
        token = next();  //an einai boolean proxwraei ola kala
    } else if (token.type.name().equals("identifierTK")) {
        token = next(); 
        args();  //edw elegxei an einai pinakas
    } else if (token.type.name().equals("lparenTK")) {
        token = next();  //an einai aristerh parenthesh
        exprList();  //elegxei an einai expression kai an einai parapanw apo ena 
        //kai meta perimenei deksia parenthesi
        if (!token.type.name().equals("rparenTK")) {
            error("Expected ')' after expression");
        }
        token = next();
        
    } else if (token.type.name().equals("minusTK")) {
        // edw vlepei gia arnhtikous arithmous
        token = next(); //prospernaei to "-"
        if(token.type.name().equals("numericTK")) {
            constant();//kai meta perimenei arithmo
        } else {
            error("Expected numeric constant after minus");
        }
    } else if (token.type.name().equals("notTK")) {
        token = next();//an einai logiko not to prospernaei
        factor();//kai ksana kalei ton eauto ths gia na dei ti uparxei meta
    }
    else {
        error("Unexpected factor");
    }
    }
    
    //-------------------------------------------------------------------
    // term = ...
    //------------------------------------------------------------------- 
    public static void term() {//vriskei ton oro kai kanei elegxei tis prakseis
    factor(); 

    while (token.type.name().equals("timesTK") || 
            token.type.name().equals("divisionTK") || 
            token.type.name().equals("moduloTK")
            ) {
        multiplyOperator();  //pairnei ton operaator
        factor();  //kai sunexizei thn idia douleia oso uparxoun dedomena kai operators
         }
    }
    
    //-------------------------------------------------------------------
    // constant = NUMERIC
    //          | STRING
    //          | TRUE
    //          | FALSE
    //          | MINUS NUMERIC
    //------------------------------------------------------------------- 
    public static void constant() {//afou hr8e edw vrisketai se constant token kai
        //elegxei poio apo ta parakatw einai.. an den einai kapoio apo auta yparxei la9os giati den vrisketai se constant
    if (token.type.name().equals("numericTK")) {
        token = next();  
    } else if (token.type.name().equals("stringConstTK")) {
        token = next();  
    } else if (token.type.name().equals("trueTK") || token.type.name().equals("falseTK")) {
        token = next();  
    } else if (token.type.name().equals("minusTK") && tokens.get(0).type.name().equals("numericTK")) {
        token = next();  //se pepriptwsh pou vrike arnhtiko arithmo se auth th fash prospernaei to "-"
        token = next();  //kai se auth th fash ton arithmo
    } else {
        error("Expected a constant");
    }
    }
    
    //-------------------------------------------------------------------
    // relationOperator = EQUAL
    //                  | NOT_EQUAL
    //                  | LT
    //                  | GT
    //                  | LTE
    //                  | GTE
    //------------------------------------------------------------------- 
    public static void relationOperator() {//psaxnei na vrei to token isothtas
    if (
        token.type.name().equals("equalTK") ||
        token.type.name().equals("notEqualTK") ||
        token.type.name().equals("ltTK") ||
        token.type.name().equals("gtTK") ||
        token.type.name().equals("lteTK") ||
        token.type.name().equals("gteTK")
    ) {
        token = next();
    } else {//an den vrei token isothtas vgazei la9os
        error("Expected relation operator");
    }
    }
    
    //-------------------------------------------------------------------
    // addingOperator   = PLUS
    //                  | MINUS
    //                  | CONCAT
    //------------------------------------------------------------------- 
    public static void addingOperator() {
    if (token.type.name().equals("plusTK") || token.type.name().equals("minusTK") || token.type.name().equals("concatTK")) {
        token = next();  
    } else {
        error("Expected adding operator");
    }
    }

    //-------------------------------------------------------------------
    // multiplyOperator = TIMES
    //                  | DIVISION
    //                  | MODULO
    //------------------------------------------------------------------- 
    public static void multiplyOperator() {
    if (token.type.name().equals("timesTK") || token.type.name().equals("divisionTK") || token.type.name().equals("moduloTK")) {
        token = next();  
    } else {
        error("Expected multiplication operator");
    }
    }
    
    public static void main(String args[]) {

        // path to the input file
        Lex lex = new Lex("./test/sample5.spl");
        tokens = lex.getTokens();
        
        token = next();
        program();
    }
}
