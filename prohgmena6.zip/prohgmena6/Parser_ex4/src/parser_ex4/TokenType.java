/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser_ex4;


public enum TokenType {
//-------------------------------------------------------------------
// Whitespeace, Newline, Comments
//-------------------------------------------------------------------       
    whitespaceTK("[ \t\f\r]+"),
    newlineTK("\n"),
    commentTK("\\{[^\\n\\{\\}]*\\}"),//dexete ta panta mesa sto comment ektos 
    //apo newline, kai emfolevmena comments { }
//-------------------------------------------------------------------
// Constants
//-------------------------------------------------------------------    
    numericTK("\\d+\\.\\d+([eE][+-]?\\d+)?|\\d+([eE][+-]?\\d+)?|\\.\\d+([eE][+-]?\\d+)?"),
    stringConstTK("\"(?:[^\"\\\\]|\\\\[\"\\\\/bfnrt]|\\\\u[0-9a-fA-F]{4})*\""),
//-------------------------------------------------------------------
// Keywords
//-------------------------------------------------------------------
    programTK("PROGRAM"),
    integerTK("INTEGER"),
    booleanTK("BOOLEAN"),
    stringTK("STRING"),
    arrayTK("ARRAY"),
    ofTK("OF"),
    readTK("READ"),
    writeTK("WRITE"),
    ifTK("IF"),
    thenTK("THEN"),
    elseTK("ELSE"),
    whileTK("WHILE"),
    doTK("DO"),
    exitTK("EXIT"),
    varTK("VAR"),
    bodyTK("BODY"),
    beginTK("BEGIN"),
    endTK("END"),
    andTK("AND"),
    orTK("OR"),
    notTK("NOT"),
    trueTK("TRUE"),
    falseTK("FALSE"),
//-------------------------------------------------------------------
// Identifiers
//-------------------------------------------------------------------    
    identifierTK("[a-zA-Z_][a-zA-Z0-9_]*"),
//-------------------------------------------------------------------
// Operators
//-------------------------------------------------------------------   
    timesTK("\\*"),
    divisionTK("\\/"),
    moduloTK("%"),
    plusTK("\\+"),
    minusTK("\\-"),
    equalTK("="),
    notEqualTK("<>"),
    lteTK("<="),
    gteTK(">="),
    ltTK("<"),
    gtTK(">"),
    concatTK("\\|"),
    assignTK(":="),
//-------------------------------------------------------------------
// Punctuators/Separators
//-------------------------------------------------------------------    
    lparenTK("\\("),
    rparenTK("\\)"),
    lbrackTK("\\["),
    rbrackTK("\\]"),
    semicolonTK(";"),
    colonTK(":"),
    commaTK(","),
//-------------------------------------------------------------------
// Special tokens
//-------------------------------------------------------------------    
    unknownTK("."),
    eofTK("\\Z"),;

    public final String pattern;

    private TokenType(String pattern) {
        this.pattern = pattern;
    }
}
